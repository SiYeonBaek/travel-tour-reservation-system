package com.korea.ttrs;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import util.MyCommon;
@Controller
public class PayController {



		// 상품 화면 
		@RequestMapping("/pay1.do")
		public String pay1_form() {
			return MyCommon.USER_VIEW_PATH + "home.jsp";
		}
//		
//		// 일정 선택 화면
		@RequestMapping("/pay2.do")
		public String pay3_form() {
			return MyCommon.USER_VIEW_PATH + "home3.jsp";
		}
		
		// 안내 및 인원 지정 화면
		@RequestMapping("/pay3.do")
		public String pay4_form() {
			return MyCommon.USER_VIEW_PATH + "home4.jsp";
		}
		
		// 결제 관련 입력 화면
		@RequestMapping("/pay4.do")
		public String pay5_form() {
			return MyCommon.USER_VIEW_PATH + "home5.jsp";
		}
		
		
}
