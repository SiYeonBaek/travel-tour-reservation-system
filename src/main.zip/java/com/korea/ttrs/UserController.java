package com.korea.ttrs;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import util.MyCommon;
import vo.UserVO;

@Controller
public class UserController {

	// Login 입력 페이지로 이동
	@RequestMapping("/userLoing_form.do")
	public String userLogin_form() {
		return MyCommon.USER_VIEW_PATH + "userLoing_form.jsp";
	}
	
	// 회원가입 선택 페이지로 이동 -> 사이트&카카오&네이버 로그인 선택
	@RequestMapping("/userSignUpSelect.do")
	public String userSignUpSelect() {
		return MyCommon.USER_VIEW_PATH + "userSignUpSelect.jsp";
	}
	
	// 회원가입 페이지로 이동
	@RequestMapping("/UserSignUp_form.do")
	public String userSignUp_form() {
		return MyCommon.USER_VIEW_PATH + "userSignUp_form.jsp";
	}
	
//	@RequestMapping("/userLogin.do")
//	public String userLogin(UserVO vo) {
//		return MyCommon.USER_VIEW_PATH + "userLogin_form.jsp";
//	}
}
