package util;

public class MyCommon {

	// User Folder Path
	public static final String USER_VIEW_PATH = "/WEB-INF/views/pay/";
	
}
